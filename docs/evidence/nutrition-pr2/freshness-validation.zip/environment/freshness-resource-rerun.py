import json, subprocess, os, sys
from pathlib import Path
nodes=json.loads(Path('instance/freshness-full-rerun-nodes.json').read_text())
groups={}
for n in nodes: groups.setdefault(n.split('::')[0],[]).append(n)
results=[]
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for i,(file,cases) in enumerate(groups.items()):
    log=Path('docs/evidence/nutrition-pr2/freshness-resource-rerun-'+str(i)+'.txt')
    temp=Path('instance/freshness-resource-rerun-'+str(i)).resolve()
    root=Path.cwd().resolve()
    assert temp.is_relative_to(root) and not temp.exists()
    args=[sys.executable,'-X','utf8','-u','-m','pytest','-q','--tb=short','--basetemp',str(temp),'-o','cache_dir=instance/freshness-resource-cache-'+str(i),*cases]
    print('START',i,file,len(cases),flush=True)
    with log.open('w',encoding='utf-8') as out: r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,env=env)
    results.append(dict(file=file,cases=len(cases),exit_code=r.returncode,log=str(log)))
    Path('instance/freshness-resource-rerun-results.json').write_text(json.dumps(results,indent=2))
    print('DONE',i,r.returncode,flush=True)
sys.exit(int(any(r['exit_code'] for r in results)))
