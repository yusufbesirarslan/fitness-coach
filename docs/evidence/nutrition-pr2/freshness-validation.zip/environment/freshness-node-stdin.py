import json, subprocess, sys
from pathlib import Path
original=subprocess.run
def transport(args,*a,**kw):
    if isinstance(args,(list,tuple)) and len(args)==3 and Path(args[0]).name.lower() in ('node','node.exe') and args[1]=='-e' and len(args[2])>30000:
        kw['input']=args[2]; args=[args[0],'-']
    return original(args,*a,**kw)
subprocess.run=transport
import pytest
nodes=[n for n in json.loads(Path('instance/freshness-full-rerun-nodes.json').read_text()) if n.startswith('tests/test_progress_axis_insight.py::')]
sys.exit(pytest.main(['-q','--tb=short','--basetemp','instance/freshness-node-stdin-temp','-o','cache_dir=instance/freshness-node-stdin-cache',*nodes]))
